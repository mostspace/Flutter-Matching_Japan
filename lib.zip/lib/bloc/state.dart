part of 'cubit.dart';

abstract class AppState {}
class AppInitial extends AppState {}

// ! ---------> register

class AppRegister extends AppState {}

// ! ---------> main

class AppMain extends AppState {}